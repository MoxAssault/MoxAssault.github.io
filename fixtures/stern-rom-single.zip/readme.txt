Stern test fixture: exactly one .bin inside.
